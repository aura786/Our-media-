
import React from 'react';
import { Chrome } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  return (
    <div className="h-screen flex flex-col items-center justify-center bg-slate-50 px-6 overflow-hidden relative">
      {/* Decorative Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-64 h-64 bg-orange-300/30 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-[-5%] right-[-10%] w-80 h-80 bg-amber-400/20 rounded-full blur-3xl animate-pulse delay-700"></div>

      <div className="z-10 text-center max-w-sm">
        <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-amber-600 rounded-3xl flex items-center justify-center shadow-2xl mx-auto mb-8 transform rotate-12 animate-bounce-slow">
          <span className="text-white font-black text-5xl">M</span>
        </div>
        
        <h1 className="text-4xl font-black text-slate-900 mb-2">Our Media</h1>
        <p className="text-slate-500 font-medium mb-12">The world's coolest social media built just for kids!</p>
        
        <div className="space-y-4">
          <button 
            onClick={onLogin}
            className="w-full flex items-center justify-center gap-4 bg-white border-2 border-slate-200 py-4 px-6 rounded-2xl font-bold text-slate-700 shadow-lg shadow-slate-200/50 hover:bg-slate-50 active:scale-95 transition-all"
          >
            <Chrome className="text-orange-500" />
            Continue with Google
          </button>
          
          <p className="text-[10px] text-slate-400 px-8 leading-relaxed">
            By joining, you agree to our friendly <span className="underline">Safety Rules</span> and <span className="underline">Privacy Promise</span>.
          </p>
        </div>
      </div>
      
      <div className="absolute bottom-8 text-center">
        <p className="text-xs font-bold text-orange-500/60 uppercase tracking-widest">Safe • Fun • Creative</p>
      </div>

      <style>{`
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(0) rotate(12deg); }
          50% { transform: translateY(-15px) rotate(12deg); }
        }
        .animate-bounce-slow {
          animation: bounce-slow 4s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default LoginScreen;
