
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Trash2, ShieldAlert, Users, TrendingUp, AlertTriangle, PlayCircle, Heart, DollarSign, Check, X } from 'lucide-react';
import { Post, UserProfile } from '../types';

interface AdminTabProps {
  posts: Post[];
  setPosts: React.Dispatch<React.SetStateAction<Post[]>>;
  isDarkMode: boolean;
  isSuperAdmin: boolean;
  userId: string;
  users: UserProfile[];
  setUsers: React.Dispatch<React.SetStateAction<UserProfile[]>>;
}

const AdminTab: React.FC<AdminTabProps> = ({ posts, setPosts, isDarkMode, isSuperAdmin, userId, users, setUsers }) => {
  const filteredPosts = useMemo(() => {
    if (isSuperAdmin) return posts;
    return posts.filter(p => p.userId === userId);
  }, [posts, isSuperAdmin, userId]);

  const pendingRequests = useMemo(() => {
    return users.filter(u => u.hezzStatus === 'pending');
  }, [users]);

  const stats = useMemo(() => {
    const totalEarnings = filteredPosts.reduce((sum, p) => sum + p.revenue, 0);
    const totalLikes = filteredPosts.reduce((sum, p) => sum + p.likes, 0);
    
    const postTypes = {
      Video: filteredPosts.filter(p => p.type === 'Video').length,
      Post: filteredPosts.filter(p => p.type === 'Post').length,
      Script: filteredPosts.filter(p => p.type === 'Script').length,
    };

    const chartData = [
      { name: 'Video', count: postTypes.Video, fill: '#f97316' },
      { name: 'Post', count: postTypes.Post, fill: '#3b82f6' },
      { name: 'Script', count: postTypes.Script, fill: '#8b5cf6' },
    ];

    return { totalEarnings, totalLikes, postTypes, chartData };
  }, [filteredPosts]);

  const handleDelete = (id: string) => {
    if (confirm('Permanently delete this content?')) {
      setPosts(posts.filter(p => p.id !== id));
    }
  };

  const handleHezzResponse = (uid: string, status: 'active' | 'denied') => {
    // 1. Update user monetization status
    setUsers(prev => prev.map(u => u.uid === uid ? { ...u, hezzStatus: status } : u));
    
    // 2. If approved, retroactively enable monetization (ads) on all their existing posts
    if (status === 'active') {
      setPosts(prev => prev.map(p => p.userId === uid ? { ...p, hezzEnabled: true } : p));
    }
    
    alert(`Application successfully ${status === 'active' ? 'APPROVED' : 'DENIED'}!`);
  };

  return (
    <div className="space-y-8 pb-10">
      <div className="flex items-center gap-3">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm ${isSuperAdmin ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'}`}>
          {isSuperAdmin ? <ShieldAlert size={28} /> : <TrendingUp size={28} />}
        </div>
        <div>
          <h2 className="text-xl font-black">{isSuperAdmin ? 'Platform Dashboard' : 'Your Analysis'}</h2>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">
            {isSuperAdmin ? 'Lifetime Admin Control' : 'Content Performance'}
          </p>
        </div>
      </div>

      {/* Hezz Requests for Super Admin */}
      {isSuperAdmin && pendingRequests.length > 0 && (
        <div className={`p-6 rounded-3xl border border-amber-200 bg-amber-50/50 dark:bg-amber-900/10 dark:border-amber-900 shadow-xl animate-in zoom-in duration-300`}>
          <h3 className="font-black text-amber-700 dark:text-amber-500 mb-4 flex items-center gap-2">
            <Users size={18} />
            Hezz Mode Requests ({pendingRequests.length})
          </h3>
          <div className="space-y-3">
            {pendingRequests.map(user => (
              <div key={user.uid} className={`p-4 rounded-2xl bg-white dark:bg-slate-900 border border-amber-100 dark:border-amber-900/40 flex items-center justify-between shadow-sm`}>
                <div className="flex items-center gap-3">
                  <img src={user.photo} className="w-10 h-10 rounded-full border-2 border-amber-400" />
                  <div>
                    <p className="font-bold text-sm">{user.name}</p>
                    <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">UID: {user.uid.slice(-6)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleHezzResponse(user.uid, 'active')}
                    className="p-2 bg-green-500 text-white rounded-full hover:scale-110 active:scale-95 transition-all shadow-lg"
                    title="Approve"
                  >
                    <Check size={18} />
                  </button>
                  <button 
                    onClick={() => handleHezzResponse(user.uid, 'denied')}
                    className="p-2 bg-red-500 text-white rounded-full hover:scale-110 active:scale-95 transition-all shadow-lg"
                    title="Deny"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className={`p-6 rounded-3xl border shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <Heart className="text-red-500 mb-2" size={24} />
          <p className="text-2xl font-black">{stats.totalLikes}</p>
          <p className="text-[10px] font-bold text-slate-400 uppercase">{isSuperAdmin ? 'Total Likes' : 'Your Likes'}</p>
        </div>
        <div className={`p-6 rounded-3xl border shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <DollarSign className="text-green-500 mb-2" size={24} />
          <p className="text-2xl font-black">₹{stats.totalEarnings.toFixed(2)}</p>
          <p className="text-[10px] font-bold text-slate-400 uppercase">{isSuperAdmin ? 'Platform Rev' : 'Your Revenue'}</p>
        </div>
      </div>

      {/* Chart */}
      <div className={`p-6 rounded-3xl border shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
        <h3 className="font-bold text-sm mb-6 flex items-center gap-2">
          <PlayCircle size={18} className="text-orange-500" />
          Content Distribution
        </h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats.chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#334155' : '#e2e8f0'} />
              <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
              <YAxis fontSize={10} axisLine={false} tickLine={false} />
              <Tooltip 
                cursor={{ fill: 'transparent' }}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
              />
              <Bar dataKey="count" radius={[8, 8, 0, 0]} barSize={40}>
                {stats.chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Content List */}
      <div className="space-y-4">
        <h3 className="font-bold text-sm flex items-center gap-2">
          {isSuperAdmin ? <AlertTriangle size={18} className="text-red-500" /> : <PlayCircle size={18} className="text-orange-500" />}
          {isSuperAdmin ? 'Platform Moderation' : 'Your Content Stats'}
        </h3>
        {filteredPosts.length === 0 ? (
          <div className="text-center py-10 bg-slate-100 dark:bg-slate-800/50 rounded-2xl">
            <p className="text-slate-400 text-sm italic font-bold">No data found.</p>
          </div>
        ) : (
          filteredPosts.map(post => (
            <div key={post.id} className={`p-4 rounded-2xl border flex items-center justify-between group transition-all animate-in slide-in-from-bottom-2 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
              <div className="flex items-center gap-3 overflow-hidden">
                <img src={post.poster} alt="" className="w-12 h-12 rounded-lg object-cover shrink-0" />
                <div className="min-w-0">
                  <p className="font-bold text-sm truncate">{post.title}</p>
                  <div className="flex items-center gap-2">
                     <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest truncate">
                      {post.userName} • {post.likes}❤️ • ₹{post.revenue}
                    </p>
                    {post.hezzEnabled && (
                      <span className="text-[8px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded font-black uppercase">AD ON</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => handleDelete(post.id)}
                  className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-xl transition-colors"
                  title="Delete"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminTab;
