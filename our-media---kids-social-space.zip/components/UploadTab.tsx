
import React, { useState } from 'react';
import { Video, Type, FileText, Camera, UploadCloud, Info, Link as LinkIcon } from 'lucide-react';
import { ContentType, Post, UserProfile } from '../types';

interface UploadTabProps {
  onUpload: (post: Post) => void;
  isDarkMode: boolean;
  currentUser: UserProfile;
}

const UploadTab: React.FC<UploadTabProps> = ({ onUpload, isDarkMode, currentUser }) => {
  const [type, setType] = useState<ContentType>('Video');
  const [title, setTitle] = useState('');
  const [poster, setPoster] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [document, setDocument] = useState('');
  const [scriptContent, setScriptContent] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [isUploading, setIsUploading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return alert('Give it a title!');
    if (!poster) return alert('Need a poster link (thumbnail)!');
    if (type === 'Video' && !videoUrl) return alert('Paste a video link!');

    setIsUploading(true);
    
    setTimeout(() => {
      const isMonetized = currentUser.hezzStatus === 'active';
      const newPost: Post = {
        id: Math.random().toString(36).substring(7),
        type,
        userId: currentUser.uid,
        userName: currentUser.name,
        userPhoto: currentUser.photo,
        title,
        poster,
        videoUrl: type === 'Video' ? videoUrl : undefined,
        document: type === 'Video' ? document : undefined,
        scriptContent: type === 'Script' ? scriptContent : undefined,
        pollOptions: type === 'Post' ? pollOptions.filter(o => o.trim()).map((opt, i) => ({ id: `p${i}`, text: opt, votes: 0 })) : undefined,
        createdAt: Date.now(),
        revenue: 0,
        hezzEnabled: isMonetized,
        likes: 0,
        status: 'public',
        comments: []
      };

      onUpload(newPost);
      setIsUploading(false);
      setTitle('');
      setPoster('');
      setVideoUrl('');
      setDocument('');
      setScriptContent('');
      setPollOptions(['', '']);
    }, 1200);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="text-center">
        <h2 className="text-3xl font-black italic text-orange-600">Create Magic!</h2>
        <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Share your world with friends</p>
      </div>

      <div className="flex bg-slate-200 dark:bg-slate-800 p-1 rounded-2xl gap-1">
        {(['Video', 'Post', 'Script'] as ContentType[]).map(t => (
          <button
            key={t}
            onClick={() => setType(t)}
            className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-2 text-sm font-black transition-all ${type === t ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30' : 'text-slate-500'}`}
          >
            {t === 'Video' && <Video size={18} />}
            {t === 'Post' && <Type size={18} />}
            {t === 'Script' && <FileText size={18} />}
            {t}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-5 bg-white dark:bg-slate-900 p-6 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-xl">
        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Title</label>
          <input 
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="Write a cool title..."
            className={`w-full p-4 rounded-2xl outline-none focus:ring-4 focus:ring-orange-500/20 transition-all ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-50 text-slate-800'}`}
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Poster Link (Thumbnail Image)</label>
          <div className="relative">
            <input 
              value={poster}
              onChange={e => setPoster(e.target.value)}
              placeholder="Paste image link here..."
              className={`w-full p-4 pl-12 rounded-2xl outline-none focus:ring-4 focus:ring-orange-500/20 transition-all ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-50 text-slate-800'}`}
            />
            <Camera className="absolute left-4 top-1/2 -translate-y-1/2 text-orange-500" size={20} />
          </div>
        </div>

        {type === 'Video' && (
          <>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Video Link (MP4/WebM)</label>
              <div className="relative">
                <input 
                  value={videoUrl}
                  onChange={e => setVideoUrl(e.target.value)}
                  placeholder="Paste direct video link..."
                  className={`w-full p-4 pl-12 rounded-2xl outline-none focus:ring-4 focus:ring-orange-500/20 transition-all ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-50 text-slate-800'}`}
                />
                <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-orange-500" size={20} />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Document (Description)</label>
              <textarea 
                value={document}
                onChange={e => setDocument(e.target.value)}
                placeholder="What is this video about?"
                rows={3}
                className={`w-full p-4 rounded-2xl outline-none focus:ring-4 focus:ring-orange-500/20 transition-all ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-50 text-slate-800'}`}
              />
            </div>
          </>
        )}

        {/* Post & Script sections remain same... */}
        {type === 'Post' && (
          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Poll Choices</label>
            {pollOptions.map((opt, i) => (
              <input
                key={i}
                value={opt}
                onChange={e => {
                  const newOpts = [...pollOptions];
                  newOpts[i] = e.target.value;
                  setPollOptions(newOpts);
                }}
                placeholder={`Option ${i+1}`}
                className={`w-full p-3 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/20 transition-all ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-50 text-slate-800'}`}
              />
            ))}
            <button type="button" onClick={() => setPollOptions([...pollOptions, ''])} className="text-orange-500 text-xs font-black uppercase tracking-widest">+ Add Option</button>
          </div>
        )}

        {type === 'Script' && (
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">The White Board (Script Content)</label>
            <textarea 
              value={scriptContent}
              onChange={e => setScriptContent(e.target.value)}
              placeholder="Write your story here..."
              rows={8}
              className={`w-full p-5 rounded-[28px] outline-none font-mono text-sm leading-relaxed ${isDarkMode ? 'bg-black text-slate-300' : 'bg-slate-50 text-slate-800'}`}
            />
            <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900/10 rounded-xl">
              <Info size={16} className="text-blue-600 shrink-0" />
              <p className="text-[10px] text-blue-700 dark:text-blue-400 italic">Scripts earn rewards when other creators use them in their videos!</p>
            </div>
          </div>
        )}

        <button 
          type="submit"
          disabled={isUploading}
          className="w-full py-5 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-[24px] font-black text-xl shadow-2xl shadow-orange-500/40 active:scale-95 disabled:opacity-50 transition-all flex items-center justify-center gap-3"
        >
          {isUploading ? (
            <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <>
              <UploadCloud size={24} />
              PUBLISH NOW
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default UploadTab;
