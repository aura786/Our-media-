
import React, { useState } from 'react';
import { 
  Settings, 
  ShieldCheck, 
  LogOut, 
  ChevronRight, 
  HelpCircle, 
  FileLock, 
  ArrowLeft,
  Bell,
  Eye,
  CheckCircle2,
  ListVideo,
  Trash2,
  Globe,
  Lock,
  Sparkles
} from 'lucide-react';
import { UserProfile, Post } from '../types';

interface AccountTabProps {
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  isDarkMode: boolean;
  posts: Post[];
  setPosts: React.Dispatch<React.SetStateAction<Post[]>>;
}

type AccountView = 'profile' | 'settings' | 'privacy' | 'terms' | 'feedback' | 'manager';

const AccountTab: React.FC<AccountTabProps> = ({ currentUser, setCurrentUser, isDarkMode, posts, setPosts }) => {
  const [currentView, setCurrentView] = useState<AccountView>('profile');
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSent, setFeedbackSent] = useState(false);
  
  const [notificationsOn, setNotificationsOn] = useState(true);
  const [kidSafeOn, setKidSafeOn] = useState(true);

  const userPosts = posts.filter(p => p.userId === currentUser.uid);

  const handleApplyHezz = () => {
    if (currentUser.hezzStatus !== 'none') return;
    const updatedUser: UserProfile = { ...currentUser, hezzStatus: 'pending' };
    setCurrentUser(updatedUser);
    alert("Application Sent! Admin will review your profile soon.");
  };

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim()) return;
    setFeedbackSent(true);
    setTimeout(() => {
      setFeedbackSent(false);
      setFeedbackText('');
      setCurrentView('profile');
    }, 2000);
  };

  const handleDeletePost = (id: string) => {
    if (confirm('Delete this content forever?')) {
      setPosts(prev => prev.filter(p => p.id !== id));
    }
  };

  const handleToggleStatus = (id: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === id) {
        return { ...p, status: p.status === 'public' ? 'private' : 'public' };
      }
      return p;
    }));
  };

  const SubPageHeader = ({ title }: { title: string }) => (
    <div className="flex items-center gap-4 mb-6">
      <button 
        onClick={() => setCurrentView('profile')}
        className={`p-2 rounded-full transition-all active:scale-90 ${isDarkMode ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
      >
        <ArrowLeft size={20} />
      </button>
      <h2 className="text-xl font-black">{title}</h2>
    </div>
  );

  const Toggle = ({ isOn, onToggle, colorClass }: { isOn: boolean, onToggle: () => void, colorClass: string }) => (
    <button 
      onClick={onToggle}
      className={`w-12 h-6 rounded-full relative p-1 transition-colors duration-300 ease-in-out ${isOn ? colorClass : 'bg-slate-300 dark:bg-slate-700'}`}
    >
      <div className={`w-4 h-4 bg-white rounded-full transition-transform duration-300 ease-in-out shadow-sm ${isOn ? 'translate-x-6' : 'translate-x-0'}`}></div>
    </button>
  );

  if (currentView === 'manager') {
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-10">
        <SubPageHeader title="Content Manager" />
        <div className="space-y-4">
          {userPosts.length === 0 ? (
            <div className="p-10 text-center bg-white dark:bg-slate-900 rounded-[32px] border border-dashed border-slate-200 dark:border-slate-800">
              <p className="text-slate-400 font-bold italic">You haven't posted anything yet!</p>
            </div>
          ) : (
            userPosts.map(post => (
              <div key={post.id} className={`p-4 rounded-3xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} shadow-sm flex flex-col gap-4`}>
                <div className="flex gap-4">
                  <img src={post.poster} className="w-20 h-20 rounded-2xl object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-sm truncate">{post.title}</h4>
                    <p className="text-[10px] text-slate-400 uppercase font-black">{post.type} • {post.likes} likes</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[8px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest ${post.status === 'public' ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-500'}`}>
                        {post.status}
                      </span>
                      {post.hezzEnabled && (
                        <span className="text-[8px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest bg-blue-100 text-blue-600 flex items-center gap-1">
                          <Sparkles size={8} /> Monetized
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 border-t pt-3 border-slate-50 dark:border-slate-800">
                  <button 
                    onClick={() => handleToggleStatus(post.id)}
                    className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2 transition-all ${post.status === 'public' ? 'bg-slate-100 dark:bg-slate-800 text-slate-500' : 'bg-orange-500 text-white shadow-lg shadow-orange-500/20'}`}
                  >
                    {post.status === 'public' ? <Lock size={12} /> : <Globe size={12} />}
                    {post.status === 'public' ? 'Private' : 'Public'}
                  </button>
                  <button 
                    onClick={() => handleDeletePost(post.id)}
                    className="p-2 rounded-xl bg-red-50 dark:bg-red-950/20 text-red-500 hover:bg-red-100 transition-all"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  }

  // Settings, Privacy, Terms, Feedback views remain mostly same...
  if (currentView === 'settings') {
    return (
      <div className="animate-in slide-in-from-right duration-300">
        <SubPageHeader title="Settings" />
        <div className={`rounded-3xl border overflow-hidden ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <div className="p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${isDarkMode ? 'bg-orange-500/10' : 'bg-orange-50'}`}>
                    <Bell size={20} className="text-orange-500" />
                </div>
                <div>
                    <span className="font-bold block">Notifications</span>
                    <span className="text-[10px] text-slate-400 font-medium italic">Alerts for your magic</span>
                </div>
              </div>
              <Toggle isOn={notificationsOn} onToggle={() => setNotificationsOn(!notificationsOn)} colorClass="bg-orange-500" />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${isDarkMode ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
                    <Eye size={20} className="text-blue-500" />
                </div>
                <div>
                    <span className="font-bold block">Kid-Safe Filter</span>
                    <span className="text-[10px] text-slate-400 font-medium italic">Auto Content Moderation</span>
                </div>
              </div>
              <Toggle isOn={kidSafeOn} onToggle={() => setKidSafeOn(!kidSafeOn)} colorClass="bg-green-500" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Default Profile View
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className={`p-8 rounded-[40px] text-center relative overflow-hidden shadow-2xl ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
        <div className="absolute top-0 left-0 w-full h-28 bg-gradient-to-br from-orange-400 to-amber-600"></div>
        <div className="relative mt-10">
          <img src={currentUser.photo} className="w-28 h-28 rounded-full mx-auto border-4 border-white dark:border-slate-800 shadow-xl object-cover" />
          <div className="mt-4">
            <h2 className={`text-3xl font-black ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{currentUser.name}</h2>
            <div className="inline-block mt-1 px-3 py-1 bg-orange-100 dark:bg-orange-500/10 rounded-full">
              <span className="text-orange-600 dark:text-orange-400 font-bold text-[10px] uppercase tracking-tighter">ID: (In){currentUser.uid.slice(0, 8)}</span>
            </div>
          </div>
        </div>

        <div className="flex gap-4 mt-8">
          <div className={`flex-1 p-4 rounded-3xl border ${isDarkMode ? 'bg-slate-800/30 border-slate-700' : 'bg-slate-50 border-slate-100 shadow-inner'}`}>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Balance</p>
            <div className="flex items-center justify-center gap-1 text-green-500 font-black text-2xl">
              <span>₹</span><span>{currentUser.earnings.toFixed(2)}</span>
            </div>
          </div>
          <div className={`flex-1 p-4 rounded-3xl border ${isDarkMode ? 'bg-slate-800/30 border-slate-700' : 'bg-slate-50 border-slate-100 shadow-inner'}`}>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">H-Status</p>
            <p className={`text-xs font-black mt-1 uppercase ${
              currentUser.hezzStatus === 'active' ? 'text-blue-500' : 
              currentUser.hezzStatus === 'pending' ? 'text-amber-500' : 
              currentUser.hezzStatus === 'denied' ? 'text-red-500' : 'text-slate-400'
            }`}>
              {currentUser.hezzStatus === 'none' ? 'InActive' : currentUser.hezzStatus}
            </p>
          </div>
        </div>

        <button 
          onClick={handleApplyHezz}
          disabled={currentUser.hezzStatus !== 'none'}
          className={`mt-6 w-full py-5 rounded-[24px] font-black text-lg flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95 ${
            currentUser.hezzStatus === 'active' ? 'bg-blue-500 text-white' : 
            currentUser.hezzStatus === 'pending' ? 'bg-amber-100 text-amber-600' : 
            currentUser.hezzStatus === 'denied' ? 'bg-red-50 text-red-500' : 
            'bg-orange-500 text-white hover:shadow-orange-500/20'
          }`}
        >
          {currentUser.hezzStatus === 'none' ? 'APPLY HEZZ MODE 🚀' : 
           currentUser.hezzStatus === 'pending' ? 'WAITING FOR ADMIN ⏳' : 
           currentUser.hezzStatus === 'active' ? 'MONETIZATION ON! ✨' : 'DENIED BY ADMIN ❌'}
        </button>
      </div>

      <div className={`rounded-[32px] border divide-y overflow-hidden shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800 divide-slate-800' : 'bg-white border-slate-100 divide-slate-100'}`}>
        <button onClick={() => setCurrentView('manager')} className="w-full p-5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group text-left">
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-xl bg-orange-50 dark:bg-orange-950/20 text-orange-500 group-hover:scale-110 transition-transform">
                <ListVideo size={20} />
            </div>
            <span className="font-bold text-sm">Content Manager</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>

        <button onClick={() => setCurrentView('settings')} className="w-full p-5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group text-left">
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 group-hover:scale-110 transition-transform">
                <Settings size={20} />
            </div>
            <span className="font-bold text-sm">App Settings</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>

        {/* Other sections... */}
        <button onClick={() => setCurrentView('privacy')} className="w-full p-5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group text-left">
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-900/20 text-blue-500 group-hover:scale-110 transition-transform">
                <ShieldCheck size={20} />
            </div>
            <span className="font-bold text-sm">Privacy Protection</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>

        <button onClick={() => setCurrentView('terms')} className="w-full p-5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group text-left">
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-900/20 text-purple-500 group-hover:scale-110 transition-transform">
                <FileLock size={20} />
            </div>
            <span className="font-bold text-sm">Kids Rules</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>

        <button onClick={() => setCurrentView('feedback')} className="w-full p-5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group text-left">
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-xl bg-green-50 dark:bg-green-900/20 text-green-500 group-hover:scale-110 transition-transform">
                <HelpCircle size={20} />
            </div>
            <span className="font-bold text-sm">Talk to Us</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>
      </div>

      <button onClick={() => window.location.reload()} className="w-full p-5 flex items-center justify-center gap-3 text-red-500 font-black bg-red-50 dark:bg-red-950/20 rounded-[24px] transition-all hover:bg-red-100 mb-6">
        <LogOut size={20} />
        Good Bye!
      </button>
    </div>
  );
};

export default AccountTab;
