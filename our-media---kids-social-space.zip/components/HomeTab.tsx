
import React, { useState, useEffect } from 'react';
import { RefreshCcw, MoreHorizontal, MessageSquare, Share2, Heart, Play, X, FileText, Send, Check, EyeOff, AlertTriangle, Sparkles } from 'lucide-react';
import { Post, UserProfile, Comment } from '../types';

interface HomeTabProps {
  posts: Post[];
  setPosts: React.Dispatch<React.SetStateAction<Post[]>>;
  isDarkMode: boolean;
  currentUser: UserProfile;
}

const HomeTab: React.FC<HomeTabProps> = ({ posts, setPosts, isDarkMode, currentUser }) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [viewingScript, setViewingScript] = useState<Post | null>(null);
  const [viewingComments, setViewingComments] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState('');
  const [shareToast, setShareToast] = useState(false);
  
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [hiddenPostIds, setHiddenPostIds] = useState<Set<string>>(new Set());
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      setActiveMenuId(null);
    }, 800);
  };

  const handleLike = (id: string) => {
    if (likedPosts.has(id)) {
      setLikedPosts(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      setPosts(prev => prev.map(p => p.id === id ? { ...p, likes: Math.max(0, p.likes - 1) } : p));
    } else {
      setLikedPosts(prev => new Set(prev).add(id));
      setPosts(prev => prev.map(p => {
        if (p.id === id) {
          // Simulate revenue increase on like if post is monetized
          const revenueInc = p.hezzEnabled ? 0.05 : 0;
          return { ...p, likes: p.likes + 1, revenue: p.revenue + revenueInc };
        }
        return p;
      }));
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !viewingComments) return;

    const newComment: Comment = {
      id: Math.random().toString(36).substring(7),
      userId: currentUser.uid,
      userName: currentUser.name,
      userPhoto: currentUser.photo,
      text: commentText,
      createdAt: Date.now()
    };

    setPosts(prev => prev.map(p => 
      p.id === viewingComments.id 
        ? { ...p, comments: [...(p.comments || []), newComment], revenue: p.hezzEnabled ? p.revenue + 0.10 : p.revenue } 
        : p
    ));

    setCommentText('');
    setViewingComments(prev => prev ? { ...prev, comments: [...(prev.comments || []), newComment] } : null);
  };

  const handleShare = async (post: Post) => {
    const shareData = {
      title: 'Our Media',
      text: `Check out this ${post.type} on Our Media: ${post.title}`,
      url: window.location.href
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.text + " " + shareData.url);
        setShareToast(true);
        setTimeout(() => setShareToast(false), 2000);
      }
    } catch (err) {
      console.error('Sharing failed', err);
    }
  };

  const handleHide = (id: string) => {
    setHiddenPostIds(prev => new Set(prev).add(id));
    setActiveMenuId(null);
  };

  const handleReport = (id: string) => {
    if (confirm("Report this post? Our team will review it for safety.")) {
      alert("Post reported! Thank you for keeping Our Media safe.");
      setHiddenPostIds(prev => new Set(prev).add(id));
      setActiveMenuId(null);
    }
  };

  const threeDaysAgo = Date.now() - (3 * 24 * 60 * 60 * 1000);
  const filteredPosts = posts
    .filter(p => p.createdAt >= threeDaysAgo && p.status === 'public' && !hiddenPostIds.has(p.id))
    .sort((a, b) => b.createdAt - a.createdAt);

  const getTimeAgo = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff/60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff/3600000)}h ago`;
    return `${Math.floor(diff/86400000)}d ago`;
  };

  return (
    <div className="space-y-6 pb-4" onClick={() => setActiveMenuId(null)}>
      <div className="flex items-center justify-between mb-2">
        <h2 className={`text-lg font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-800'}`}>Fresh Feeds</h2>
        <button onClick={handleRefresh} className={`p-2 rounded-full ${isRefreshing ? 'animate-spin text-orange-500' : 'text-slate-400'}`}>
          <RefreshCcw size={20} />
        </button>
      </div>

      {filteredPosts.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-[32px] border border-dashed border-slate-300">
          <p className="text-slate-500 font-bold italic">The feed is empty! Be the first to upload.</p>
        </div>
      ) : (
        filteredPosts.map(post => (
          <div key={post.id} className={`rounded-[32px] overflow-hidden shadow-sm border relative animate-in fade-in slide-in-from-bottom-4 duration-500 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
            <div className="p-4 flex items-center justify-between relative">
              <div className="flex items-center gap-3">
                <img src={post.userPhoto} className="w-10 h-10 rounded-full object-cover border-2 border-orange-400" />
                <div>
                  <h3 className="font-bold text-sm">{post.userName}</h3>
                  <p className="text-[10px] text-slate-500 uppercase">{getTimeAgo(post.createdAt)}</p>
                </div>
              </div>
              <div className="relative">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenuId(activeMenuId === post.id ? null : post.id);
                  }}
                  className={`p-2 rounded-full transition-colors ${activeMenuId === post.id ? 'bg-slate-100 dark:bg-slate-800' : 'text-slate-400'}`}
                >
                  <MoreHorizontal size={20} />
                </button>
                
                {activeMenuId === post.id && (
                  <div className={`absolute right-0 top-12 z-50 w-40 rounded-2xl border shadow-xl animate-in zoom-in-95 duration-200 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-100 text-slate-800'}`}>
                    <div className="p-2 space-y-1">
                      <button 
                        onClick={() => handleHide(post.id)}
                        className="w-full text-left px-3 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                      >
                        <EyeOff size={16} />
                        Hide Post
                      </button>
                      <button 
                        onClick={() => handleReport(post.id)}
                        className="w-full text-left px-3 py-2 rounded-xl text-sm font-bold flex items-center gap-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors"
                      >
                        <AlertTriangle size={16} />
                        Report
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="relative aspect-video bg-black flex items-center justify-center">
              {playingId === post.id && post.videoUrl ? (
                <video 
                  src={post.videoUrl} 
                  controls 
                  autoPlay 
                  className="w-full h-full object-contain"
                  onEnded={() => setPlayingId(null)}
                />
              ) : (
                <>
                  <img src={post.poster} className="w-full h-full object-cover opacity-80" />
                  {post.type === 'Video' && (
                    <button 
                      onClick={() => setPlayingId(post.id)}
                      className="absolute inset-0 flex items-center justify-center group"
                    >
                      <div className="w-16 h-16 bg-orange-500/90 rounded-full flex items-center justify-center text-white shadow-2xl group-hover:scale-110 transition-transform">
                        <Play size={32} fill="white" />
                      </div>
                    </button>
                  )}
                  {post.type === 'Script' && (
                    <div className="absolute top-4 right-4 bg-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">
                      Script
                    </div>
                  )}
                  {post.hezzEnabled && (
                    <div className="absolute top-4 left-4 bg-blue-500/90 backdrop-blur-sm text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg flex items-center gap-2">
                      <Sparkles size={12} />
                      Monetized
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="p-5">
              <h4 className="text-lg font-black leading-tight mb-2">{post.title}</h4>
              
              {post.type === 'Video' && post.document && (
                <p className="text-sm text-slate-500 line-clamp-2 leading-relaxed mb-4">{post.document}</p>
              )}

              {post.type === 'Post' && post.pollOptions && (
                <div className="space-y-2 mb-4">
                  {post.pollOptions.map(option => (
                    <button key={option.id} className="w-full text-left p-3 rounded-2xl border bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700 flex justify-between items-center group active:scale-95 transition-all">
                      <span className="text-sm font-bold">{option.text}</span>
                      <span className="text-[11px] font-black text-orange-500">{option.votes} votes</span>
                    </button>
                  ))}
                </div>
              )}

              {post.type === 'Script' && (
                <button 
                  onClick={() => setViewingScript(post)}
                  className="w-full p-4 mb-4 rounded-2xl bg-orange-50 dark:bg-orange-950/20 border border-orange-100 dark:border-orange-900 text-orange-600 dark:text-orange-400 font-bold flex items-center justify-center gap-2 group transition-all"
                >
                  <FileText size={18} />
                  Read Full Script
                </button>
              )}

              <div className="flex items-center gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button 
                  onClick={() => handleLike(post.id)} 
                  className={`flex items-center gap-1.5 font-bold transition-all group ${likedPosts.has(post.id) ? 'text-red-500' : 'text-slate-500 hover:text-red-500'}`}
                >
                  <Heart 
                    size={20} 
                    fill={likedPosts.has(post.id) ? "currentColor" : "none"} 
                    className={`group-active:scale-150 transition-transform ${likedPosts.has(post.id) ? 'animate-in zoom-in duration-300' : ''}`} 
                  />
                  <span className="text-sm">{post.likes}</span>
                </button>
                <button 
                  onClick={() => setViewingComments(post)}
                  className="flex items-center gap-1.5 text-slate-500 font-bold hover:text-orange-500 transition-colors group"
                >
                  <MessageSquare size={20} className="group-active:scale-110 transition-transform" />
                  <span className="text-sm">{post.comments?.length || 0}</span>
                </button>
                <button 
                  onClick={() => handleShare(post)}
                  className="flex items-center gap-1.5 text-slate-500 font-bold ml-auto hover:text-blue-500 transition-colors group"
                >
                  <Share2 size={20} className="group-active:scale-110 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        ))
      )}

      {/* Modals remain same... */}
      {viewingScript && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-[40px] overflow-hidden flex flex-col max-h-[80vh] shadow-2xl">
            <div className="p-6 border-b flex items-center justify-between bg-orange-500 text-white">
              <h3 className="font-black text-xl line-clamp-1">{viewingScript.title}</h3>
              <button onClick={() => setViewingScript(null)} className="p-1 hover:bg-white/20 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-8 overflow-y-auto font-mono text-sm leading-relaxed whitespace-pre-wrap flex-1 no-scrollbar">
              {viewingScript.scriptContent || "No content found in this script."}
            </div>
          </div>
        </div>
      )}

      {viewingComments && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300" onClick={(e) => e.stopPropagation()}>
          <div className="w-full max-w-lg bg-slate-50 dark:bg-slate-950 rounded-t-[40px] sm:rounded-[40px] overflow-hidden flex flex-col h-[85vh] sm:h-[70vh] shadow-2xl">
            <div className={`p-5 flex items-center justify-between border-b ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div>
                <h3 className="font-black text-lg">Talk Thread</h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{viewingComments.comments?.length || 0} Replies</p>
              </div>
              <button onClick={() => setViewingComments(null)} className="p-2 bg-slate-100 dark:bg-slate-800 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4 no-scrollbar">
              {!viewingComments.comments || viewingComments.comments.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-10">
                  <div className="w-16 h-16 bg-orange-100 dark:bg-orange-950/20 rounded-full flex items-center justify-center mb-4">
                    <MessageSquare size={32} className="text-orange-500" />
                  </div>
                  <p className="text-sm font-bold text-slate-400">No one has spoken yet. Start the talk!</p>
                </div>
              ) : (
                viewingComments.comments.map(comment => (
                  <div key={comment.id} className="flex gap-3 animate-in slide-in-from-bottom-2 duration-300">
                    <img src={comment.userPhoto} className="w-8 h-8 rounded-full border-2 border-white shadow-sm shrink-0" />
                    <div className={`p-3 rounded-2xl max-w-[85%] ${comment.userId === currentUser.uid ? 'bg-orange-500 text-white rounded-tr-none ml-auto' : isDarkMode ? 'bg-slate-900 text-slate-100 rounded-tl-none' : 'bg-white text-slate-800 border rounded-tl-none shadow-sm'}`}>
                      {comment.userId !== currentUser.uid && <p className="text-[10px] font-black opacity-60 mb-1">{comment.userName}</p>}
                      <p className="text-sm font-medium">{comment.text}</p>
                      <p className={`text-[8px] mt-1 opacity-50 font-bold ${comment.userId === currentUser.uid ? 'text-right' : ''}`}>
                        {getTimeAgo(comment.createdAt)}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

            <form onSubmit={handleAddComment} className={`p-4 border-t ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="relative flex items-center">
                <input 
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  placeholder="Share your thought..."
                  className={`w-full py-4 pl-5 pr-14 rounded-full border-none outline-none font-bold text-sm ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-800'}`}
                />
                <button 
                  type="submit"
                  disabled={!commentText.trim()}
                  className="absolute right-2 w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white disabled:opacity-50 transition-all active:scale-90"
                >
                  <Send size={18} />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {shareToast && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[200] bg-slate-900 text-white px-6 py-3 rounded-full font-black text-sm flex items-center gap-3 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-300">
          <Check size={18} className="text-green-500" />
          INVITE LINK COPIED!
        </div>
      )}
    </div>
  );
};

export default HomeTab;
